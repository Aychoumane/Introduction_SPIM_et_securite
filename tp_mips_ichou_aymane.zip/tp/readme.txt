Ligne de commande : 

ocamlc -o new mips.ml mips_helper.ml spk.ml 
 
